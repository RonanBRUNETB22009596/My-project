Les modèles Blender du baril et de la pièce ne sont pas inclus dans ce dossier en raison de leur taille volumineuse. 

- Baril : 53 Ko  
- Pièce : 905 Ko  

Les pièces utilisées dans le jeu Unity sont les miennes, et l'unique image du baril peut être retrouvée dans le rapport Blender au format PDF inclus. 

Je m'excuse pour ce désagrément.  

Merci pour votre compréhension.  